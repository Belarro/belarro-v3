module.exports=[69723,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app__not-found_page_actions_0lnyjt0.js.map