module.exports=[90582,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_orders_page_actions_0nmpqgh.js.map