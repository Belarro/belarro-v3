module.exports=[78071,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_invoices_page_actions_12m9aqm.js.map