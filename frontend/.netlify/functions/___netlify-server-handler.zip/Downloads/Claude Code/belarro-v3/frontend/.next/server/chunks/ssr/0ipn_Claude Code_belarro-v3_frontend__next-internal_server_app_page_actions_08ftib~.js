module.exports=[55306,(a,b,c)=>{}];

//# sourceMappingURL=0ipn_Claude%20Code_belarro-v3_frontend__next-internal_server_app_page_actions_08ftib~.js.map