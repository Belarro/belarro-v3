module.exports=[90272,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_crops_page_actions_0ed63oe.js.map