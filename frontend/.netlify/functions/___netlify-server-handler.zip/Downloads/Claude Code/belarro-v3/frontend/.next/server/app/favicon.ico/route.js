var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__0vy691o._.js")
R.c("server/chunks/10e-_next_dist_esm_build_templates_app-route_0g0astf.js")
R.c("server/chunks/0~q0_belarro-v3_frontend__next-internal_server_app_favicon_ico_route_actions_0ah15u6.js")
R.m(99721)
module.exports=R.m(99721).exports
