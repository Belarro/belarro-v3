module.exports=[6857,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_inventory_page_actions_0~dr7n9.js.map