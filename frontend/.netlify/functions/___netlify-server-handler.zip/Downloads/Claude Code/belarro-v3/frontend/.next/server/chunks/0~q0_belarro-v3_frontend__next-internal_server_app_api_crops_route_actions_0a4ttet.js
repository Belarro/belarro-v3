module.exports=[12123,(e,o,d)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_api_crops_route_actions_0a4ttet.js.map