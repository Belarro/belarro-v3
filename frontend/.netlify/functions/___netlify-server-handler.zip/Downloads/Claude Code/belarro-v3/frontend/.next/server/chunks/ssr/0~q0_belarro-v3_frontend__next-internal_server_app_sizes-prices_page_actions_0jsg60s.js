module.exports=[7359,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_sizes-prices_page_actions_0jsg60s.js.map