var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/crops/route.js")
R.c("server/chunks/[root-of-the-server]__09_qjhp._.js")
R.c("server/chunks/[root-of-the-server]__0vy691o._.js")
R.c("server/chunks/0~q0_belarro-v3_frontend__next-internal_server_app_api_crops_route_actions_0a4ttet.js")
R.m(44005)
module.exports=R.m(44005).exports
