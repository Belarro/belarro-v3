module.exports=[6637,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_follow-ups_page_actions_00hddv..js.map