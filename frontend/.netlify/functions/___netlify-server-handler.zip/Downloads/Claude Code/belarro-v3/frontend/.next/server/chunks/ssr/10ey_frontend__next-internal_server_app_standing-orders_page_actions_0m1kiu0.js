module.exports=[41095,(a,b,c)=>{}];

//# sourceMappingURL=10ey_frontend__next-internal_server_app_standing-orders_page_actions_0m1kiu0.js.map