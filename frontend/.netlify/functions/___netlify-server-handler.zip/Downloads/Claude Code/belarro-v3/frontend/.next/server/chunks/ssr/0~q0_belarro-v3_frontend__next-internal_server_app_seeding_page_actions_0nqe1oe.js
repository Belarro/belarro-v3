module.exports=[13984,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_seeding_page_actions_0nqe1oe.js.map