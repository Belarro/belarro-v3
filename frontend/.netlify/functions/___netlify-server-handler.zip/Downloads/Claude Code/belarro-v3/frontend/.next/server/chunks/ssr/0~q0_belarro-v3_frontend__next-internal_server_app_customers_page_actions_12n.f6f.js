module.exports=[13688,(a,b,c)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_customers_page_actions_12n.f6f.js.map