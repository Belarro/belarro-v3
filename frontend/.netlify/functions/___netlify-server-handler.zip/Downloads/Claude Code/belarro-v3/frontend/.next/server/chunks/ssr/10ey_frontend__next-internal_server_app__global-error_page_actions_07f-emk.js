module.exports=[93393,(a,b,c)=>{}];

//# sourceMappingURL=10ey_frontend__next-internal_server_app__global-error_page_actions_07f-emk.js.map