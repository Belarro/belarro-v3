module.exports=[15162,(e,o,d)=>{}];

//# sourceMappingURL=0~q0_belarro-v3_frontend__next-internal_server_app_favicon_ico_route_actions_0ah15u6.js.map