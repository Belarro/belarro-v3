globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/H4YwkaJ4OUt3Qd6Hiq99g/_buildManifest.js",
    "static/H4YwkaJ4OUt3Qd6Hiq99g/_ssgManifest.js",
    "static/H4YwkaJ4OUt3Qd6Hiq99g/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/05kouq6qn2jud.js",
    "static/chunks/07i6v9cw.oxry.js",
    "static/chunks/0y2e~x.sv3~-..js",
    "static/chunks/turbopack-0csvh_u7o-v~f.js"
  ]
};
