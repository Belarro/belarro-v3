globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/uzu_4fT4RWKSnfEjj6FHo/_buildManifest.js",
    "static/uzu_4fT4RWKSnfEjj6FHo/_ssgManifest.js",
    "static/uzu_4fT4RWKSnfEjj6FHo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/05kouq6qn2jud.js",
    "static/chunks/07i6v9cw.oxry.js",
    "static/chunks/0y2e~x.sv3~-..js",
    "static/chunks/turbopack-0csvh_u7o-v~f.js"
  ]
};
